HOW TO UPDATE :

Upload the Update.zip file to your project root path. 

Changes We made :


[PATCH] Compatible with HyipLab v3.7
