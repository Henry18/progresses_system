HOW TO UPDATE :

Upload the Update.zip file to your project root path. 

Changes We made :


[ADD] Staking option added
[ADD] Pool option added
[ADD] Metamask login option added
[PATCH] Compatible with HyipLab v4.0
