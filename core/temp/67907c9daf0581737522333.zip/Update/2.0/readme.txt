HOW TO UPDATE :

Upload the Update.zip file to your project root path and import the update.sql to your project database. 

Changes We made :


[PATCH] Compatible with HyipLab v5.0
